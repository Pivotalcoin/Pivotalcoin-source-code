Sample configuration files for:
```
SystemD: pivotalcoind.service
Upstart: pivotalcoind.conf
OpenRC:  pivotalcoind.openrc
         pivotalcoind.openrcconf
CentOS:  pivotalcoind.init
macOS:    org.pivotalcoin.pivotalcoind.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
